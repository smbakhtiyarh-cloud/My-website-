(function () {
  "use strict";

  const config = window.STORE_CONFIG || {};
  const products = Array.isArray(window.STORE_PRODUCTS) ? window.STORE_PRODUCTS : [];
  const CART_STORAGE_KEY = "nimco-house-cart-v1";
  const currency = new Intl.NumberFormat("en-PK", {
    style: "currency", currency: config.CURRENCY || "PKR", maximumFractionDigits: 0
  });

  const state = {
    activeCategory: "All",
    query: "",
    cart: loadCart(),
    toastTimer: null,
    lastFocus: null
  };

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));
  const money = amount => currency.format(Number(amount) || 0).replace("PKR", "Rs.").replace(/\u00a0/g, " ");
  const getProduct = id => products.find(product => product.id === id);
  const safeText = value => String(value == null ? "" : value);

  function loadCart() {
    try {
      const parsed = JSON.parse(localStorage.getItem(CART_STORAGE_KEY) || "{}");
      if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return {};
      const valid = {};
      for (const [id, quantity] of Object.entries(parsed)) {
        const product = products.find(item => item.id === id);
        const qty = Number(quantity);
        if (product && product.available !== false && Number.isInteger(qty) && qty > 0 && qty <= 99) valid[id] = qty;
      }
      return valid;
    } catch (_) {
      return {};
    }
  }

  function saveCart() {
    try { localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(state.cart)); } catch (_) { /* Storage may be blocked; cart still works for this page view. */ }
  }

  function escapeHtml(value) {
    return safeText(value).replace(/[&<>"']/g, char => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    }[char]));
  }

  function cartCount() {
    return Object.values(state.cart).reduce((sum, quantity) => sum + quantity, 0);
  }

  function cartSubtotal() {
    return Object.entries(state.cart).reduce((sum, [id, quantity]) => {
      const product = getProduct(id);
      return sum + (product ? product.price * quantity : 0);
    }, 0);
  }

  function deliveryFee() {
    const subtotal = cartSubtotal();
    const fee = Math.max(0, Number(config.DELIVERY_FEE) || 0);
    const threshold = Math.max(0, Number(config.FREE_DELIVERY_OVER) || 0);
    if (subtotal <= 0 || (threshold > 0 && subtotal >= threshold)) return 0;
    return fee;
  }

  function estimatedTotal() { return cartSubtotal() + deliveryFee(); }

  function renderProducts() {
    const grid = $("#productGrid");
    const normalizedQuery = state.query.trim().toLocaleLowerCase();
    const visible = products.filter(product => {
      const categoryMatches = state.activeCategory === "All" || product.category === state.activeCategory;
      const searchText = [product.name, product.subtitle, product.category, product.description, product.size].join(" ").toLocaleLowerCase();
      return categoryMatches && (!normalizedQuery || searchText.includes(normalizedQuery));
    });

    grid.innerHTML = visible.map(product => {
      const available = product.available !== false;
      return `
        <article class="product-card">
          <div class="product-visual tone-${escapeHtml(product.tone || "gold")}">
            ${product.badge ? `<span class="product-sticker">${escapeHtml(product.badge)}</span>` : ""}
            ${product.image ? `<img class="product-photo" src="${escapeHtml(product.image)}" alt="${escapeHtml(product.name)} packet" loading="lazy">` : `<span class="product-emoji" aria-hidden="true">${escapeHtml(product.imageEmoji || "🥨")}</span>`}
            <span class="product-size">${escapeHtml(product.size || "Pack")}</span>
          </div>
          <div class="product-info">
            <div class="product-meta"><span>${escapeHtml(product.category)}</span><span>${available ? "In stock" : "Sold out"}</span></div>
            <h3>${escapeHtml(product.name)}</h3>
            <p class="product-subtitle">${escapeHtml(product.subtitle || "A snack-time favourite")}</p>
            <p class="product-description">${escapeHtml(product.description || "A tasty, crunchy favourite for your snack stash.")}</p>
            <div class="product-buy-row">
              <div class="product-price">${money(product.price)}<small>per pack</small></div>
              <button class="add-button" type="button" data-add="${escapeHtml(product.id)}" ${available ? "" : "disabled"} aria-label="Add ${escapeHtml(product.name)} to bag">${available ? "Add to bag" : "Sold out"}${available ? " <span aria-hidden=\"true\">+</span>" : ""}</button>
            </div>
          </div>
        </article>`;
    }).join("");

    $("#noResults").hidden = visible.length > 0;
    grid.hidden = visible.length === 0;
  }

  function renderCart() {
    const count = cartCount();
    const subtotal = cartSubtotal();
    const fee = deliveryFee();
    $("#headerCartCount").textContent = count;
    $("#drawerItemCount").textContent = `(${count})`;
    $("#cartSubtotal").textContent = money(subtotal);
    $("#cartDelivery").textContent = fee === 0 && subtotal > 0 ? "FREE" : money(fee);
    $("#cartTotal").textContent = money(subtotal + fee);
    $("#checkoutSubtotal").textContent = money(subtotal);
    $("#checkoutDelivery").textContent = fee === 0 && subtotal > 0 ? "FREE" : money(fee);
    $("#checkoutTotal").textContent = money(subtotal + fee);

    const threshold = Math.max(0, Number(config.FREE_DELIVERY_OVER) || 0);
    if (subtotal > 0 && threshold > subtotal) {
      $("#deliveryHint").textContent = `Add ${money(threshold - subtotal)} more to qualify for free delivery.`;
    } else if (threshold > 0 && subtotal >= threshold) {
      $("#deliveryHint").textContent = "You've unlocked free delivery (based on the current store settings).";
    } else {
      $("#deliveryHint").textContent = "Delivery fee is based on the current store settings; confirm final fee in WhatsApp.";
    }

    const items = Object.entries(state.cart).map(([id, quantity]) => ({ product: getProduct(id), quantity })).filter(item => item.product);
    $("#cartItems").innerHTML = items.map(({ product, quantity }) => `
      <div class="cart-row">
        <div class="cart-thumb tone-${escapeHtml(product.tone || "gold")}" aria-hidden="true">${escapeHtml(product.imageEmoji || "🥨")}</div>
        <div>
          <p class="cart-product-name">${escapeHtml(product.name)}</p>
          <p class="cart-product-size">${escapeHtml(product.size || "Pack")} · ${money(product.price)} each</p>
          <div class="qty-control" aria-label="Quantity for ${escapeHtml(product.name)}">
            <button type="button" data-qty="${escapeHtml(product.id)}" data-delta="-1" aria-label="Decrease quantity">−</button>
            <span>${quantity}</span>
            <button type="button" data-qty="${escapeHtml(product.id)}" data-delta="1" aria-label="Increase quantity">+</button>
          </div>
        </div>
        <div class="cart-row-end"><strong class="cart-row-price">${money(product.price * quantity)}</strong><button class="remove-item" data-remove="${escapeHtml(product.id)}" type="button">Remove</button></div>
      </div>`).join("");

    const empty = count === 0;
    $("#cartEmpty").hidden = !empty;
    $("#cartFooter").hidden = empty;
    $("#cartItems").hidden = empty;
    $("#checkoutBtn").disabled = !config.ACCEPT_ORDERS;
  }

  function addToCart(id) {
    const product = getProduct(id);
    if (!product || product.available === false) return;
    const current = Number(state.cart[id] || 0);
    if (current >= 99) { showToast("Maximum quantity per item is 99."); return; }
    state.cart[id] = current + 1;
    saveCart();
    renderCart();
    showToast(`${product.name} added to your bag.`);
  }

  function changeQuantity(id, delta) {
    const current = Number(state.cart[id] || 0);
    const next = current + delta;
    if (next <= 0) delete state.cart[id]; else state.cart[id] = Math.min(99, next);
    saveCart();
    renderCart();
  }

  function removeItem(id) {
    delete state.cart[id];
    saveCart();
    renderCart();
    showToast("Snack removed from your bag.");
  }

  function showToast(message) {
    const toast = $("#toast");
    toast.textContent = message;
    toast.classList.add("show");
    window.clearTimeout(state.toastTimer);
    state.toastTimer = window.setTimeout(() => toast.classList.remove("show"), 2600);
  }

  function setPageLock(locked) { document.body.classList.toggle("no-scroll", locked); }

  function openCart() {
    closeCheckout(false);
    state.lastFocus = document.activeElement;
    $("#drawerBackdrop").hidden = false;
    $("#cartDrawer").classList.add("open");
    $("#cartDrawer").setAttribute("aria-hidden", "false");
    setPageLock(true);
    $("#closeCartBtn").focus();
  }

  function closeCart(restoreFocus = true) {
    $("#cartDrawer").classList.remove("open");
    $("#cartDrawer").setAttribute("aria-hidden", "true");
    $("#drawerBackdrop").hidden = true;
    if (!$("#checkoutModal").hidden) return;
    setPageLock(false);
    if (restoreFocus && state.lastFocus && typeof state.lastFocus.focus === "function") state.lastFocus.focus();
  }

  function openCheckout() {
    if (cartCount() === 0) { showToast("Add a snack to your bag first."); return; }
    const minimum = Math.max(0, Number(config.MIN_ORDER_SUBTOTAL) || 0);
    if (cartSubtotal() < minimum) {
      showToast(`Minimum order is ${money(minimum)} based on the current store settings.`);
      return;
    }
    state.lastFocus = document.activeElement;
    $("#checkoutWarning").hidden = true;
    $("#checkoutModal").hidden = false;
    $("#checkoutBackdrop").hidden = false;
    $("#checkoutModal").setAttribute("aria-hidden", "false");
    setPageLock(true);
    $("#checkoutForm [name=customerName]").focus();
  }

  function closeCheckout(restoreFocus = true) {
    $("#checkoutModal").hidden = true;
    $("#checkoutBackdrop").hidden = true;
    $("#checkoutModal").setAttribute("aria-hidden", "true");
    if ($("#cartDrawer").classList.contains("open")) {
      setPageLock(true);
      if (restoreFocus) $("#checkoutBtn").focus();
      return;
    }
    setPageLock(false);
    if (restoreFocus && state.lastFocus && typeof state.lastFocus.focus === "function") state.lastFocus.focus();
  }

  function normalizePhone(value) {
    return safeText(value).trim().replace(/[\s().-]/g, "");
  }

  function validWhatsAppNumber() {
    const number = safeText(config.WHATSAPP_NUMBER).replace(/\D/g, "");
    return /^\d{10,15}$/.test(number) ? number : "";
  }

  function buildOrderMessage(formData) {
    const lines = [
      safeText(config.WHATSAPP_GREETING || "Assalam-o-alaikum! I'd like to place this order:"),
      "",
      `*Order for ${safeText(config.STORE_NAME || "Nimco House")}*`,
      `Order date: ${new Date().toLocaleString("en-PK", { dateStyle: "medium", timeStyle: "short" })}`,
      "",
      "*Items:*"
    ];
    for (const [id, quantity] of Object.entries(state.cart)) {
      const product = getProduct(id);
      if (product) lines.push(`• ${product.name} (${product.size}) × ${quantity} = ${money(product.price * quantity)}`);
    }
    lines.push(
      "",
      `Subtotal: ${money(cartSubtotal())}`,
      `Estimated delivery: ${deliveryFee() === 0 ? "FREE" : money(deliveryFee())}`,
      `*Estimated total: ${money(estimatedTotal())}*`,
      "",
      "*Customer details:*",
      `Name: ${safeText(formData.get("customerName")).trim()}`,
      `Customer mobile: ${normalizePhone(formData.get("customerPhone"))}`,
      `City / area: ${safeText(formData.get("customerArea")).trim()}`,
      `Delivery address: ${safeText(formData.get("customerAddress")).trim()}`
    );
    const notes = safeText(formData.get("orderNotes")).trim();
    if (notes) lines.push(`Order notes: ${notes}`);
    lines.push("", safeText(config.BUSINESS_HOURS_NOTE || "Please confirm availability, delivery timing and payment arrangements."));
    lines.push("", "Please confirm this order and the final delivery fee. Thank you!");
    return lines.join("\n");
  }

  function submitOrder(event) {
    event.preventDefault();
    const warning = $("#checkoutWarning");
    warning.hidden = true;
    if (!config.ACCEPT_ORDERS) {
      warning.textContent = "Ordering is temporarily disabled. Please contact the shop directly.";
      warning.hidden = false;
      return;
    }
    if (cartCount() === 0) {
      warning.textContent = "Your bag is empty. Add at least one snack before checkout.";
      warning.hidden = false;
      return;
    }
    const number = validWhatsAppNumber();
    if (!number) {
      warning.textContent = "The shop's WhatsApp number has not been set. Open config.js and enter the real business number with country code (digits only), then refresh this page. Orders cannot be sent until this is configured.";
      warning.hidden = false;
      return;
    }
    const form = $("#checkoutForm");
    if (!form.reportValidity()) return;
    const customerPhone = normalizePhone(form.elements.customerPhone.value);
    if (customerPhone.replace(/\D/g, "").length < 7) {
      warning.textContent = "Please enter a valid customer mobile number.";
      warning.hidden = false;
      form.elements.customerPhone.focus();
      return;
    }
    const message = buildOrderMessage(new FormData(form));
    const url = `https://wa.me/${number}?text=${encodeURIComponent(message)}`;
    const opened = window.open(url, "_blank");
    if (opened) opened.opener = null;
    if (!opened) {
      warning.textContent = "Your browser blocked the WhatsApp tab. Allow pop-ups for this site or use the link below.";
      warning.hidden = false;
      let fallback = $("#whatsappFallbackLink");
      if (!fallback) {
        fallback = document.createElement("a");
        fallback.id = "whatsappFallbackLink";
        fallback.className = "text-link";
        fallback.target = "_blank";
        fallback.rel = "noopener noreferrer";
        fallback.style.marginTop = "10px";
        $("#checkoutForm").appendChild(fallback);
      }
      fallback.href = url;
      fallback.textContent = "Open prepared order in WhatsApp ↗";
      return;
    }
    showToast("WhatsApp opened with your order. Press Send there to place it.");
    closeCheckout(false);
  }

  function setup() {
    const storeName = safeText(config.STORE_NAME || "Nimco House");
    document.title = `${storeName} — Big crunch. Real flavour.`;
    $("#brandName").textContent = storeName;
    $("#footerBrandName").textContent = storeName;
    $("#copyrightName").textContent = storeName;
    $("#announcementText").textContent = safeText(config.ANNOUNCEMENT || "Fresh batches. Serious crunch. Delivered to your door.");
    $("#currentYear").textContent = new Date().getFullYear();
    $("#setupNotice").hidden = !config.SHOW_SETUP_NOTICE;

    const waNumber = validWhatsAppNumber();
    const footerWhatsApp = $("#footerWhatsApp");
    if (waNumber) {
      footerWhatsApp.href = `https://wa.me/${waNumber}`;
      footerWhatsApp.target = "_blank";
      footerWhatsApp.rel = "noopener noreferrer";
    } else {
      footerWhatsApp.href = "#shop";
      footerWhatsApp.addEventListener("click", event => {
        event.preventDefault();
        showToast("Add your real WhatsApp number in config.js to enable orders.");
      });
    }

    renderProducts();
    renderCart();

    $("#categoryFilters").addEventListener("click", event => {
      const button = event.target.closest("[data-category]");
      if (!button) return;
      state.activeCategory = button.dataset.category;
      $$(".filter-chip").forEach(chip => chip.classList.toggle("active", chip === button));
      renderProducts();
    });
    $("#productSearch").addEventListener("input", event => {
      state.query = event.target.value;
      renderProducts();
    });
    $("#productGrid").addEventListener("click", event => {
      const button = event.target.closest("[data-add]");
      if (button) addToCart(button.dataset.add);
    });
    $("#resetFiltersBtn").addEventListener("click", () => {
      state.activeCategory = "All";
      state.query = "";
      $("#productSearch").value = "";
      $$(".filter-chip").forEach(chip => chip.classList.toggle("active", chip.dataset.category === "All"));
      renderProducts();
    });
    $("#openCartBtn").addEventListener("click", openCart);
    $("#closeCartBtn").addEventListener("click", () => closeCart());
    $("#drawerBackdrop").addEventListener("click", () => closeCart());
    $("#emptyShopBtn").addEventListener("click", () => { closeCart(false); $("#shop").scrollIntoView({ behavior: "smooth" }); });
    $("#cartItems").addEventListener("click", event => {
      const qty = event.target.closest("[data-qty]");
      const remove = event.target.closest("[data-remove]");
      if (qty) changeQuantity(qty.dataset.qty, Number(qty.dataset.delta));
      else if (remove) removeItem(remove.dataset.remove);
    });
    $("#checkoutBtn").addEventListener("click", openCheckout);
    $("#closeCheckoutBtn").addEventListener("click", () => closeCheckout());
    $("#checkoutBackdrop").addEventListener("click", () => closeCheckout());
    $("#checkoutForm").addEventListener("submit", submitOrder);
    document.addEventListener("keydown", event => {
      if (event.key !== "Escape") return;
      if (!$("#checkoutModal").hidden) closeCheckout();
      else if ($("#cartDrawer").classList.contains("open")) closeCart();
    });
    $$(".faq-list details").forEach(details => {
      const sign = $("summary span", details);
      details.addEventListener("toggle", () => { if (sign) sign.textContent = details.open ? "×" : "+"; });
    });
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", setup, { once: true });
  else setup();
})();
