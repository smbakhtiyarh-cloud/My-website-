/*
 * STARTER CATALOG — these are example products/prices, not your verified menu.
 * Edit this file to match your business before publishing.
 * price is in PKR. imageEmoji is a decorative visual, not a product photo.
 */
window.STORE_PRODUCTS = [
  {
    id: "prime-nimco-50", name: "Prime Nimco Packet", subtitle: "Karachi ka mazedar swad", category: "Prime Nimco", size: "1 packet", price: 50,
    badge: "PRIME NIMCO", image: "assets/prime-nimco-packet.png", imageEmoji: "🥨", tone: "tomato", description: "Prime Nimco's crunchy savoury mix in the signature Rs. 50 packet.", available: true
  },
  {
    id: "chatpata-mix", name: "Chatpata Mix", subtitle: "A little kick, a lot of crunch", category: "Nimco Mixes", size: "250 g", price: 420,
    badge: "BOLD & SPICY", imageEmoji: "🌶️", tone: "chilli", description: "A lively spicy mix for snackers who like a little heat.", available: true
  },
  {
    id: "masala-daal", name: "Masala Daal", subtitle: "Tiny bites. Big flavour.", category: "Daal & Chana", size: "200 g", price: 250,
    badge: "CHAI PARTNER", imageEmoji: "🟡", tone: "gold", description: "Crunchy roasted daal with a tasty masala finish.", available: true
  },
  {
    id: "masala-chana", name: "Masala Chana", subtitle: "Crunch with character", category: "Daal & Chana", size: "250 g", price: 320,
    badge: "FAVOURITE", imageEmoji: "🟤", tone: "olive", description: "A savoury chana snack for the mid-afternoon munchies.", available: true
  },
  {
    id: "potato-sticks", name: "Spicy Potato Sticks", subtitle: "The packet empties itself", category: "Crunchy Bites", size: "200 g", price: 290,
    badge: "EXTRA CRUNCH", imageEmoji: "🍟", tone: "orange", description: "Light, crisp potato sticks seasoned for snack-time happiness.", available: true
  },
  {
    id: "roasted-peanuts", name: "Masala Peanuts", subtitle: "Small handful, happy heart", category: "Crunchy Bites", size: "250 g", price: 360,
    badge: "SNACK CLASSIC", imageEmoji: "🥜", tone: "peanut", description: "Peanuts with a savoury masala coating and a proper crunch.", available: true
  },
  {
    id: "family-crunch", name: "Family Crunch Bundle", subtitle: "A little something for everyone", category: "Bundles", size: "3 × 250 g", price: 950,
    badge: "BUNDLE DEAL", imageEmoji: "🎁", tone: "bundle", description: "Three assorted snack packs to keep the family tea table stocked.", available: true
  },
  {
    id: "party-pack", name: "Party Snack Box", subtitle: "Made for guests and gatherings", category: "Bundles", size: "1 kg assorted", price: 1450,
    badge: "SHARE THE LOVE", imageEmoji: "🎉", tone: "party", description: "An assorted box for get-togethers, office tea and family visits.", available: true
  }
];
