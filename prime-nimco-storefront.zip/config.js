/*
 * STORE SETTINGS — edit these before publishing.
 * WhatsApp number must include country code, numbers only; e.g. 923001234567.
 * Do not include +, spaces, or dashes. Leave blank until you add the real number.
 */
window.STORE_CONFIG = {
  STORE_NAME: "Prime Nimco",
  TAGLINE: "Karachi ka mazedar swad",
  CITY: "Karachi",
  CURRENCY: "PKR",
  WHATSAPP_NUMBER: "", // REQUIRED: replace with your real business number, e.g. 923001234567
  DELIVERY_FEE: 150, // SAMPLE: replace with your real delivery fee
  FREE_DELIVERY_OVER: 2500, // SAMPLE: set to 0 to disable free delivery threshold
  MIN_ORDER_SUBTOTAL: 500, // SAMPLE: set to 0 if you have no minimum order
  ANNOUNCEMENT: "Fresh batches. Serious crunch. Delivered to your door.",
  SHOW_SETUP_NOTICE: true, // Turn off only after you have updated the real products and prices.
  ACCEPT_ORDERS: true,
  WHATSAPP_GREETING: "Assalam-o-alaikum! I'd like to place this nimco order:",
  BUSINESS_HOURS_NOTE: "Please confirm delivery time and payment arrangements in WhatsApp.",
  INSTAGRAM_URL: ""
};
